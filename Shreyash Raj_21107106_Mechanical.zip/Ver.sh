#!/bin/bash

echo "System Information:"
echo "OS Version: $(uname -o)"
echo "Kernel Version: $(uname -r)"
echo "System Uptime: $(uptime -p)"
