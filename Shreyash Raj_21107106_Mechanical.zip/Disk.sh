#!/bin/bash

echo "Disk usage of home directory:"
du -sh $HOME
